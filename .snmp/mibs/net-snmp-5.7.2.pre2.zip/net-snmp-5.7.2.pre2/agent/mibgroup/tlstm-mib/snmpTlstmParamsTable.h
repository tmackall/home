#ifndef SNMPTLSTMPARAMSTABLE_H
#define SNMPTLSTMPARAMSTABLE_H

config_require(tlstm-mib/snmpTlstmParamsTable/snmpTlstmParamsTable)

#endif                          /* SNMPTLSTMPARAMSTABLE_H */
