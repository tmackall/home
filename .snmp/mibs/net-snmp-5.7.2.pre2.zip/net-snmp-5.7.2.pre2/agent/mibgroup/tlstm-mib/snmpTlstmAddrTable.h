#ifndef SNMPTLSTMADDRTABLE_H
#define SNMPTLSTMADDRTABLE_H

config_require(tlstm-mib/snmpTlstmAddrTable/snmpTlstmAddrTable)


#endif                          /* SNMPTLSTMADDRTABLE_H */
